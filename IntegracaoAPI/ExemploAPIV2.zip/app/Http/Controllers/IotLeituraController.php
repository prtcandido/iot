<?php

namespace App\Http\Controllers;

use App\Models\IotLeitura;
use Illuminate\Http\Request;

class IotLeituraController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        return IotLeitura::all();
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        return IotLeitura::create($request->all());
    }

    /**
     * Display the specified resource.
     */
    public function show(IotLeitura $iotLeitura)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(IotLeitura $iotLeitura)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, IotLeitura $iotLeitura)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(IotLeitura $iotLeitura)
    {
        //
    }
}
