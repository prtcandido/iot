<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class IotLeitura extends Model
{
    protected $fillable = [
        'id',
        'leitura',
        'discriminador'
    ];
}
