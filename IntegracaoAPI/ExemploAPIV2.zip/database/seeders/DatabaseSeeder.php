<?php

namespace Database\Seeders;

use App\Models\User;
use App\Models\Produto;
// use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     */
    public function run(): void
    {
        // User::factory(10)->create();

        // User::factory()->create([
        //     'name' => 'Test User',
        //     'email' => 'test@example.com',
        // ]);

        Produto::create(['descricao'=>'Produto 1','preco'=>10.10]);
        Produto::create(['descricao'=>'Produto 2','preco'=>20.20]);
        Produto::create(['descricao'=>'Produto 3','preco'=>30.30]);
    }
}
