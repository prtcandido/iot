<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

Route::get('/user', function (Request $request) {
    return $request->user();
})->middleware('auth:sanctum');

Route::resource('produtos', \App\Http\Controllers\ProdutoController::class);

Route::resource('iot_leituras', \App\Http\Controllers\IotLeituraController::class);
